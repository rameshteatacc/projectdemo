﻿using System;
using System.Windows.Forms;

namespace PerMonitorDemo
{
    public partial class SimpleLayout : Form
    {
        public SimpleLayout()
        {
            InitializeComponent();
        }
    }
}
