# .NET Metadata Dumper

This samples uses the [.NET Metadata Reader][MDReader] to dump the contents
of the [ECMA-335] metadata contained in a .NET assembly (or module).

[MDReader]: http://www.nuget.org/packages/Microsoft.Bcl.Metadata
[ECMA-335]: http://www.ecma-international.org/publications/standards/Ecma-335.htm