﻿using System;

namespace EventSourceSamples
{
    class Program
    {
        static void Main(string[] args)
        {
            AllSamples.Run();
        }
    }
}
