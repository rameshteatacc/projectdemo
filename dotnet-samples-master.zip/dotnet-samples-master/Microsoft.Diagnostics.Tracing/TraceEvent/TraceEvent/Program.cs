﻿using System;

namespace TraceEventSamples
{
    class Program
    {
        static void Main(string[] args)
        {
            AllSamples.Run();
        }
    }
}
